package com.fish.wallettest

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.bitcoinj.crypto.MnemonicCode
import org.json.JSONObject
import java.math.BigDecimal
import java.math.BigInteger
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val random = SecureRandom()
    private lateinit var chain: Spinner
    private lateinit var address: EditText
    private lateinit var result: TextView
    private lateinit var checkButton: Button
    private lateinit var testButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
        }
        val title = TextView(this).apply {
            text = "Fish"
            textSize = 32f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 8)
        }
        val intro = TextView(this).apply {
            text = "بررسی آدرس عمومی و موجودی قابل مشاهده"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        }
        chain = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("Bitcoin (BTC)", "Ethereum (ETH)")
            )
        }
        address = EditText(this).apply {
            hint = "آدرس عمومی کیف پول"
            singleLine = true
            textSize = 15f
        }
        checkButton = Button(this).apply {
            text = "بررسی موجودی"
            setOnClickListener { checkBalance() }
        }
        testButton = Button(this).apply {
            text = "آزمایش BIP-39 (۱۲ کلمه‌ای)"
            setOnClickListener { runMnemonicTest() }
        }
        result = TextView(this).apply {
            text = "آدرس عمومی را وارد کن. هرگز عبارت بازیابی یا کلید خصوصی را وارد نکن."
            textSize = 16f
            setTextIsSelectable(true)
            setPadding(4, 14, 4, 14)
        }
        root.addView(title)
        root.addView(intro)
        root.addView(chain)
        root.addView(address)
        root.addView(checkButton, fullWidth())
        root.addView(testButton, fullWidth())
        val scroll = ScrollView(this)
        scroll.addView(result)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val note = TextView(this).apply {
            text = "فقط آدرس عمومی: این برنامه قفل کیف پول را بررسی یا دور نمی‌زند. موجودی شبکه ممکن است با تأخیر یا محدودیت سرویس نمایش داده شود."
            textSize = 12f
            setPadding(0, 12, 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun fullWidth() = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)

    private fun checkBalance() {
        val addr = address.text.toString().trim()
        val isEth = chain.selectedItemPosition == 1
        if (addr.isBlank()) {
            result.text = "لطفاً آدرس عمومی را وارد کن."
            return
        }
        if (isEth && !Regex("^0x[0-9a-fA-F]{40}$").matches(addr)) {
            result.text = "قالب آدرس اتریوم معتبر نیست."
            return
        }
        if (!isEth && !(addr.matches(Regex("^(1|3)[a-km-zA-HJ-NP-Z1-9]{25,34}$")) ||
                    addr.matches(Regex("^bc1[ac-hj-np-z02-9]{11,71}$", RegexOption.IGNORE_CASE)))) {
            result.text = "قالب آدرس بیت‌کوین شناخته‌شده نیست؛ آدرس را بررسی کن."
            return
        }

        checkButton.isEnabled = false
        result.text = "در حال دریافت داده از شبکه…"
        executor.execute {
            val message = try {
                if (isEth) {
                    val body = JSONObject()
                        .put("jsonrpc", "2.0")
                        .put("method", "eth_getBalance")
                        .put("params", org.json.JSONArray().put(addr).put("latest"))
                        .put("id", 1)
                    val response = postJson("https://cloudflare-eth.com", body.toString())
                    val hex = JSONObject(response).getString("result")
                    val wei = BigInteger(hex.removePrefix("0x").ifEmpty { "0" }, 16)
                    val eth = BigDecimal(wei).divide(BigDecimal.TEN.pow(18))
                    "شبکه: Ethereum\nآدرس: $addr\nموجودی تقریبی: ${eth.stripTrailingZeros().toPlainString()} ETH\n\nمنبع: گره عمومی Cloudflare"
                } else {
                    val response = getText("https://blockchain.info/balance?active=$addr")
                    val satoshi = JSONObject(response).getJSONObject(addr).getLong("final_balance")
                    val btc = BigDecimal(satoshi).divide(BigDecimal.TEN.pow(8))
                    "شبکه: Bitcoin\nآدرس: $addr\nموجودی تقریبی: ${btc.stripTrailingZeros().toPlainString()} BTC\n\nمنبع: Blockchain.com"
                }
            } catch (e: Exception) {
                "دریافت موجودی ناموفق بود.\nاتصال اینترنت یا محدودیت سرویس را بررسی کن.\nجزئیات: ${e.message ?: "خطای شبکه"}"
            }
            runOnUiThread {
                result.text = message
                checkButton.isEnabled = true
            }
        }
    }

    private fun runMnemonicTest() {
        testButton.isEnabled = false
        result.text = "در حال آزمایش تولید عبارت‌های تصادفی معتبر BIP-39…"
        executor.execute {
            val start = System.nanoTime()
            var count = 0
            try {
                repeat(1000) {
                    val entropy = ByteArray(16)
                    random.nextBytes(entropy)
                    val words = MnemonicCode.INSTANCE.toMnemonic(entropy)
                    if (words.size == 12) count++
                }
                val seconds = (System.nanoTime() - start) / 1_000_000_000.0
                runOnUiThread {
                    result.text = "آزمایش پایان یافت.\nتعداد نمونه‌ها: 1000\nعبارت‌های ۱۲ کلمه‌ای معتبر: $count\nزمان: ${"%.2f".format(seconds)} ثانیه\n\nهیچ عبارت بازیابی‌ای نمایش داده یا ذخیره نشد."
                    testButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    result.text = "خطا در آزمایش: ${e.message ?: "نامشخص"}"
                    testButton.isEnabled = true
                }
            }
        }
    }

    private fun getText(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection)
        conn.connectTimeout = 12000
        conn.readTimeout = 12000
        conn.requestMethod = "GET"
        return try {
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun postJson(url: String, body: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection)
        conn.connectTimeout = 12000
        conn.readTimeout = 12000
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        return try {
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            stream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
