plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fish.wallettest"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fish.wallettest"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("org.bitcoinj:bitcoinj-core:0.17")
}
